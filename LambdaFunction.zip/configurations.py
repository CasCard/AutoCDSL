"""
You should not share this file with anyone as they contain 
your login credentials to Zerodha and CDSL pin
"""

KITE_USERNAME="Your Kite User Name"
KITE_PASSWORD="Your Kite Password"
KITE_PIN="Your Kite Pin"

CDSL_PIN="Your CDSL Pin"